const CACHE_VERSION='projeto-fit-20261005-2';

self.addEventListener('install',event=>{
  self.skipWaiting();
});

self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.map(k=>caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET') return;

  // HTML/navigation must always come from the network so new deployments appear immediately.
  if(req.mode==='navigate' || (req.headers.get('accept')||'').includes('text/html')){
    event.respondWith(fetch(req,{cache:'no-store'}).catch(()=>caches.match(req)));
    return;
  }

  // Other assets: network first; no permanent stale app shell.
  event.respondWith(fetch(req).catch(()=>caches.match(req)));
});
